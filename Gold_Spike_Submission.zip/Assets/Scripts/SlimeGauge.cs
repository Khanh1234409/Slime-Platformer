using UnityEngine;

public class SlimeGauge : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.CompareTag("Collectable Slime"))
        {
            transform.localScale += new Vector3(1, 1, 0);
            Destroy(other.gameObject);
        }
    }
}

// public class SlimeGaugeEvent
// {
//     public float currentGuage = 0;
//     public SlimeGaugeEvent(float _currentGuage) {currentGuage = _currentGuage;}
// }
